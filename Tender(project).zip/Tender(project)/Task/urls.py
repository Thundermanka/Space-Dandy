from django.conf.urls import url
from . import views

urlpatterns = patterns(’ ’,
url (r’^list_task$’ , views.list_tasks, name=’list_tasks’)
url (r'^(?P<event_id>\\d+)/$', views.Событие, name='Событие'),