from django.apps import AppConfig


class LinksConfig(AppConfig):
    name = 'links'
