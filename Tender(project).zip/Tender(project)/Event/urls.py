from django.conf.urls import url
from . import views

urlpatterns = patterns(’ ’,
url (r’^new_event$’ , views.new_event, name=’new_event’)
url (r’^list$’ , views.list, name=’list’)
url (r’ ^add_task$’ , views. ’Новая задача’, name=’Новая задача’)
url (r'^(?P<event_id>\\d+)/task_list/$', views.Новая задача, name='Новая_задача'),